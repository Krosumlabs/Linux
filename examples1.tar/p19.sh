 read -p "Enter a shell name:" sh_var
 case $sh_var in
 bash) echo "matched shell name is:${sh_var}" 
       fname="bashrc"
       ;;
 ksh) echo "matched shell name is:${sh_var}"
      fname="kshrc"
      ;;
 csh) echo "matched shell name is:${sh_var}"
      fname="cshrc"
      ;;
  *)  echo "Sorry your input shell: $sh_var is not matched"
      sh_var="/bin/nologin"
      fname="/etc/profile"
 esac 
 echo "Shell name is:${sh_var} profile filename:${fname}"
