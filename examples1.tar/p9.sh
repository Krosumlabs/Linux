r1=`$1`
r2=`$2`
r3=`$3`
r4=`$4`
r5=`$5`
cmd_results=() # empty array
  
cmd_results[0]=$r1
cmd_results[1]=$r2
cmd_results[2]=$r3
cmd_results[3]=$r4
cmd_results[4]=$r5
echo "Command results:-"
echo "-------------------------"
echo "${cmd_results[@]}"

