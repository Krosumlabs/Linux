ping -c $1 $2 >$3
