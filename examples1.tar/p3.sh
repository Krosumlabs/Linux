fname="/etc/passwd"
echo "About ${fname} file details:-
-----------------------------------"
ls -l ${fname}

