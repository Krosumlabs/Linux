echo $1 $2 $3
echo $2 $5 $8
echo ${1} ${2} ${3}
echo ${10} ${11} ${15}
echo "Total no.of args:$#"
echo "$@"
echo
echo "$*"
