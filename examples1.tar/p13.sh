read -p "Enter n value:" n

if [ $n -gt 500 ]
then
	echo "True block"
	echo "n value is:$n"
	n=`expr $n + 100`
else
	echo "False block"
	n=`expr $n - 10`
fi

echo "updated n value is:$n"
