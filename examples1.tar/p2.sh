ename="Mr.Raj"
eid=1345
edept="sales"
today=`date +%D`

echo "TODAY:${today}
----------------------------------------------
Emp name is:${ename}
${ename} id is:${eid}
${ename} working department is:${edept}
----------------------------------------------"
