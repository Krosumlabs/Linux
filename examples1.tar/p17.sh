if [ `whoami` == "root" ]
then
	cat /etc/issue
else
	echo "Sorry `whoami` your not a root user"
fi
