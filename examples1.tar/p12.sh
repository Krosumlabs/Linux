echo "This is `basename $0` file"
fname=`basename $0`
echo "script file name is:$fname"
echo "PID:$$  PPID:$PPID"
