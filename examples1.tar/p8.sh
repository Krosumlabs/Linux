A=($@)
echo "${A[@]}"  # same as $@
echo "${#A[@]}" # same as $#

