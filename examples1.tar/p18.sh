read -p "Enter a shell name:" sh_var

if [ "$sh_var" == "bash" ];then
	fname="bashrc"
elif [ "$sh_var" == "ksh" ];then
	fname="kshrc"
elif [ "$sh_var" == "csh" ];then
	fname="cshrc"
else
	echo "Sorry your input shell:$sh_var is not matched"
	echo "the default shell initialization is:"
	sh_var="/bin/nologin"
	fname="/etc/profile"
fi
echo "Shell name is:$sh_var   profile file name is:$fname"
