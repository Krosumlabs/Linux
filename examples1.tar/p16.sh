grep QA emp.csv
if [ $? -ne 0 ]
then
	echo "Sorry Pattern is not exists"
fi
