
grep QA emp.csv
if [ $? -eq 0 ]
then
	echo "Success"
else
	echo "Sorry Pattern is not exists"
fi
