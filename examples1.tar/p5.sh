read -p "Enter a partition name:" part_name
read -p "Enter ${part_name} file system type:" fstype
read -p "Enter ${part_name} mount point directory:" fmount
read -p "Enter ${part_name} disk usage:" fdisk

echo "About ${part_name} partition details:-
--------------------------------------------------------------
Partition name:${part_name}   File system type:${fstype}
----------------------------------------------------------------
mount point directory:${fmount} ${part_name} disk size is:${fdisk}
--------------------------------------------------------------------"
