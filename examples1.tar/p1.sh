ename="Mr.Raj"
eid=1345
edept="sales"
today=`date +%D`

echo "TODAY:${today}"
echo "----------------------------------------------"
echo "Emp name is:${ename}"
echo "${ename} id is:${eid}"
echo "${ename} working department is:${edept}"
echo "----------------------------------------------"
