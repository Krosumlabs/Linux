read -p "Enter a partition name:" p1
read -p "Enter $p1 partition Size:" s1

read -p "Enter a partition name:" p2
read -p "Enter $p2 partition Size:" s2

total=`expr $s1 + $s2` # total=$((s1+s2))

echo "
Partition ${p1}   Size is:${s1} GB
Partition ${p2}   Size is:${s2} GB
----------------------------------------
         Total disk size is:${total} GB
----------------------------------------"
