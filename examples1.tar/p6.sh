echo "My Login shell name:$SHELL"
echo "Login Path:$HOME"
echo "List of files $HOME directory"
ls -l $HOME
echo # empty line
echo "Exit from $PWD directory"
