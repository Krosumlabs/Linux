#include "ab.h"
pthread_t tid[5];
int counter;
pthread_mutex_t lock;

void* doSomeThing(void *arg)
{
    pthread_mutex_lock(&lock);
    counter+=1;
    printf("\n Thread %d started\n", counter);
    system("uptime");
    printf("\n Thread %d Finished\n", counter);
    pthread_mutex_unlock(&lock);

    return NULL;
}

int main(void)
{
    int i = 0;
    int j;
    if (pthread_mutex_init(&lock, NULL) != 0)
    {
        printf("\n mutex init failed\n");
        return 1;
    }

    for(i=0;i<5;i++)
    {
        pthread_create(&(tid[i]), NULL, doSomeThing, NULL);
	i++;
    }
    for(j=0;j<5;j++)
    {
        pthread_join(tid[j], NULL);
    }
    //pthread_join(tid[1], NULL);
    pthread_mutex_destroy(&lock);

    return 0;
}
