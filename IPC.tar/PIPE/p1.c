#include "ab.h"

#define  READ    0      /* The index of the “read” end of the pipe */ 
#define  WRITE  1      /* The index of the “write” end of the pipe */  
char*  phrase ="This is sample dats"; 
main()    { 
      int fd[2], bytesRead;    
      char message[100];   /* Parent process’ message buffer */    
      pipe(fd);  /* Create  an unnamed pipe */          
      
      if(fork()==0)
      {
          close(fd[READ]);
          write(fd[WRITE],phrase,strlen(phrase)+1);
          close(fd[WRITE]);
      }
      else 
      {
          close(fd[WRITE]);
	  bytesRead=read(fd[READ],message,100);
	  printf("Read %d bytes:%s\n",bytesRead,message);
	  close(fd[READ]);
      }
}
