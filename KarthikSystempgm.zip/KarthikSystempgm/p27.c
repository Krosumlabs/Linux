#include "ab.h"
int main(){
	int pid;
	printf("process-A PID:%d and PPID:%d. \n",getpid(),getppid());
	pid=fork(); 
	if( pid != 0){
		printf("This is parent process with PID:%d and PPID:%d.\n",getpid(),getppid());
		printf("My Child PID:%d\n",pid);
	}else{
		sleep(10); 
		printf("This child process with PID:%d and PPID:%d.\n",getpid(),getppid());
	}
	printf("PID %d terminates. \n",getpid());
	return 0;
}
