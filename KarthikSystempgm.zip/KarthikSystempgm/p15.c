#include "ab.h"

int main(){
	int fd1,fd2;
	fd1=open("pop.log",O_RDONLY);
	if(fd1 == -1){
		printf("FD1=%d\n",fd1);
		perror("main code:");
	}
	fd2=open("/etc/shadow",O_RDONLY);
	if(fd2 == -1){
		printf("FD2=%d\n",fd2);
		perror("main code:");
	}
	exit(0);
}
	
