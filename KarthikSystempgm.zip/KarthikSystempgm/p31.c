#include "ab.h"
void fx(char [],char []);
int main(){
	
	int pid,pid1,pid2;
	char buf[100];	
	int status;

	if((pid1=fork()) <0){
		printf("Failed to fork process\n");
		exit(1);
	}else if(pid1 == 0)
		fx('write operation-1',"");
	

	if((pid2=fork()) <0){
		printf("Failed to fork process\n");
		exit(1);
	}else if(pid2 == 0)	
		fx('write operation-2',"");

	pid=wait(&status);
		
	write(1,buf,strlen(buf));
	pid=wait(&status);
	printf(" -- parent detects process id:%d is done\n",pid);
	write(1,buf,strlen(buf));
	pid=wait(&status);
	printf(" -- parent detects process id:%d is done\n",pid);
	printf(" .. parent exists .. \n");
	exit(0);	
}
void fx(char *v,char *s){
	int pid;
	int i;
	int status;
	char buf[100];
	
	pid=getpid();

	sprintf(buf,"%s%s child process starts (PID = %d)\n",s,v,pid);
	write(1,buf,strlen(buf));
	for(i=1;i<=5;i++){
		sprintf(buf,"%s%s child result value =%d\n",space,number,i);
		write(1,buf,strlen(buf);
	 }
	sprintf(buf,"%s%s childpid:%d is about to exit\n",space,number);
	write(1,buf,strlen(buf));
	exit(0);
}
