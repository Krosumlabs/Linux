#include "ab.h"

pid_t get_pid_from_proc_self(){
 
 char target[40];
 int pid;

 readlink("/proc/self",target,sizeof(target)); 
 sscanf(target,"%d",&pid);
 return (pid_t) pid;
}
 								
int main(){
  
printf("reports the process id:%d\n",getpid());
printf("/proc/self reports process ID %d\n",get_pid_from_proc_self());
return 0;

}

