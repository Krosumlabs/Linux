#include "ab.h"
int main(){
	int fd1,fd2,fd3;
	fd1=open("/etc/passwd",O_RDONLY);
	fd2=open("pop.log",O_RDONLY);
	fd3=open("/etc/passwd",O_RDONLY);
	printf("FD1=%d\t FD2=%d\t FD3=%d\n",fd1,fd2,fd3);
	exit(0);
}
