#include "ab.h"

int main(){

	int fd;
	fd=open("test2.log",O_CREAT|O_RDWR,0664);
	write(fd,"Hello",6);
	write(fd," Linux ",7);
	exit(0);	
}
