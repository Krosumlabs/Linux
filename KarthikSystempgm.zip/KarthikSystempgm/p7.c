#include "ab.h"
int main(){
	int fd1,fd2,fd3;
	char buf1[5],buf2[5],buf3[5];

        buf1[4]='\0';	
        buf2[4]='\0';	
        buf3[4]='\0';	
	fd1=open("/home/apelix/emp.csv",O_RDONLY);
	read(fd1,buf1,5);
	printf("fd1=%d buf1=%s\n",fd1,buf1);
	fd2=open("/home/apelix/emp.csv",O_RDONLY);
	read(fd2,buf2,5);
	printf("fd2=%d buf2=%s\n",fd2,buf2);
	fd3=open("/home/apelix/emp.csv",O_RDONLY);
	read(fd3,buf3,5);
	printf("fd3=%d buf3=%s\n",fd3,buf3);
	exit(0);
}
		

