#include<stdio.h>

int main(){
	printf("Test-1\n");
	printf("Test-2\n");
	printf("Test-3\n");
	fork();
	printf("Hello\n");
	return 0;
}
