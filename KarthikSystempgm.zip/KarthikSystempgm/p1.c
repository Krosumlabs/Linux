#include "ab.h"

int main(){
	printf("Welcome to Linux System programming\n");
	exit(0);
}
