#include "ab.h"

int main(){
	int fd1,fd2;
	char buf1[30],buf2[20];
	
	buf1[29]="\n";
	fd1=open("/home/apelix/emp.csv",O_RDONLY);
	read(fd1,buf1,29);
	printf("fd1=%d buf1=%s\n",fd1,buf1);
	exit(0);
}
		

