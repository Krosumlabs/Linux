#include "ab.h"
int main(){

	int pid;
	pid=fork();
	if(pid == 0){
		printf("This is child block - PID:%d\n",getpid());
		printf("My parent id: %d\n",getppid());
	}else{
		wait(NULL);
		printf("My Child ID:%d\n",pid);
		printf("My PID:%d\n",getpid());
	}

}
