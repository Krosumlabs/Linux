// Demonstrate cp command - low-level system call implementation

#include "ab.h"
int main(){
	char c;
	int fd1,fd2;	
	fd1=open("./p1.log",O_RDONLY);
	fd2=open("./p2.log",O_WRONLY|O_CREAT);
	while(read(fd1,&c,1) == 1){
		write(fd2,&c,1);	
	}
	exit(0);
}
