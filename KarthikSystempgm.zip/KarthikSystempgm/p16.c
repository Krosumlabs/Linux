#include "ab.h"

int main(){

	int fd1,fd2;	
	fd1=open("file1.txt",O_CREAT|O_APPEND);
	if(fd1 == -1){
		perror("message:");
		exit(0);
	}else{
		printf("file is exists\n");
	}
	fd2=fcntl(fd1,F_GETFL);
	if(fd2 == -1){
		perror("File status error:");
		exit(0);
	}else{
		printf("File status flag retrived\n");	
	}
}
