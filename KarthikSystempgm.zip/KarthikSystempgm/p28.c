#include "ab.h"
int main(){
	int pid;
	pid=fork();
	if(pid != 0){
		//parent section
		while(1)
		  sleep(1000);
	}else{
		//child section
		exit(1);		
	}
 }
