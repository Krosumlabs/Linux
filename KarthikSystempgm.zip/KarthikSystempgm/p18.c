#include "ab.h"

int main(){
	int fd1,fd2;	
	struct flock lock,bc_lock;

	fd1=open("file1.txt",O_RDONLY);
	if(fd1 == -1){
		perror("message:");
	}
	lock.l_type = F_RDLCK;
	lock.l_start= 0;
	bc_lock=lock;
	fcntl(fd1,F_GETLK,&lock);
	if(lock.l_type == F_WRLCK){
		printf("process %d has a write lock already!\n",lock.l_pid);
		exit(1);
	}
	fcntl(fd1,F_SETLK,&bc_lock);
}
