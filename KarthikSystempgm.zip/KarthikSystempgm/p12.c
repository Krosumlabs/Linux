#include "ab.h"
int main(){
	int fd1;
	char buf1[20];
	struct stat bv1;
	fd1=open("/etc/passwd",O_RDONLY);
	fstat(fd1,&bv1);
	printf("FD1=%d\n",fd1);
	printf("Inode no=%d\t block size=%d\n",bv1.st_ino,bv1.st_blocks);
	exit(0);
}
	
