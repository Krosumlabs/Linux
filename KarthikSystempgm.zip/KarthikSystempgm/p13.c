#include "ab.h"

int main(){
	int fd;
	int i;	
	fd=open("t1.txt",O_CREAT|O_RDWR,0666);
	write(fd,"abcde",5);
	lseek(fd,50,SEEK_END);
	write(fd,"AB",2);
	for(i=1;i<60;i++)
		write(fd,"/0",1);
		write(fd,"test",4);
	close(fd);
	exit(0);
}
