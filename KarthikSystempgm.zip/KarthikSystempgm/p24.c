#include "ab.h"
int main(){
	fork();
	printf("PID:%d PPID:%d\n",getpid(),getppid());
	sleep(1);
	return 0;
}
