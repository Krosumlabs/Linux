#include "ab.h"
int main(){
	int fd1;
	char *s="Welcome to Linux system programming\n";
	fd1=creat("./test1.txt",O_WRONLY);
	write(fd1,s,38);
	chmod("./test1.txt",0640);
	exit(0);
}
