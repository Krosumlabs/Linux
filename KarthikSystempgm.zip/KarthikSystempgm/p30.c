#include "ab.h"
int main(){
	int status;
	if(fork() == 0){
		exit(1);
	}else{
		wait(&status);
	}
	if(WIFEXITED(status)){
		printf("Exit status:%d\n",WEXITSTATUS(status));
	}
	return 0;
}
	
