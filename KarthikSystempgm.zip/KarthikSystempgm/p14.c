#include "ab.h"

int main(){
	link("file1","file2");
	symlink("test1.txt","test2.txt");
	exit(0);
}
