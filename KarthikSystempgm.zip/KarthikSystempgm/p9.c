// Demonstrate cp command - low-level system call implementation

#include "ab.h"
int main(){
	char c[1024];
	int fd1,fd2,nr;	
	fd1=open("./p1.log",O_RDONLY);
	fd2=open("./p3.log",O_WRONLY|O_CREAT,S_IRUSR|S_IWUSR);
	while((nr=read(fd1,c,sizeof(c))) >0){
		write(fd2,c,nr);	
	}
	exit(0);
}
