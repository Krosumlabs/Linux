#include "ab.h"

void process_args_list(pid_t pid){
	int fd;
	char fname[25];
	char arg_list[1024];
	size_t length;
	char* next_arg;

	snprintf(fname,sizeof(fname),"/proc/%d/cmdline",(int)pid);
	fd=open(fname,O_RDONLY);
	if(fd == -1){
		perror("open:");
		exit(1);
	}
	length=read(fd,arg_list,sizeof(arg_list));
	close(fd);
	arg_list[length]='\0';
	
	next_arg = arg_list;
	while(next_arg < arg_list + length){
	printf("%s\n",next_arg);
	next_arg += strlen(next_arg)+1;
	}
}
int main(int argc, char* argv[]){
	pid_t pid = (pid_t) atoi (argv[1]);
	process_args_list(pid);
	return 0;
}



# simulate ps <pid>  => /proc/<pid>/cmdline ->o/p is processname
# ------------------
# gcc -o p20 p20.c
#
# ./p20 <pid>
# ----------
