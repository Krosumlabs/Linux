#include "ab.h"

int main(){
	printf("PID:%d   PPID:%d",getpid(),getppid());
	fork();
	printf("PID:%d   PPID:%d",getpid(),getppid());
	printf("\n");
	return 0;
}
