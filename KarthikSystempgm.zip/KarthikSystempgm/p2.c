#include "ab.h"
int main(){
	printf("Hello\n");
	write(1,"abc\n",4);
	write(2,"test\n",5);
	exit(0);
}
